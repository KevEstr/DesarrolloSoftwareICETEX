package com.udea.Clase03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase03Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase03Application.class, args);
	}

}
